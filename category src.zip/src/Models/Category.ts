export interface category{
id :number;
catname:string;
}